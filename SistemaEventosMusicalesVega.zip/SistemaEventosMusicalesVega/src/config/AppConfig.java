/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package config;

/**
 *
 * @author admin
 */
public class AppConfig {
    public static final String PATH_SER = "src/data/eventos.bin";
    public static final String PATH_CSV = "src/data/eventos.csv";
    
    
}