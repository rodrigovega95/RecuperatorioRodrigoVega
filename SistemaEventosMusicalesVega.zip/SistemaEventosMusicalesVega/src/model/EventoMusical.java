package model;

import java.time.LocalDate;
import service.CSVSerializable;

public class EventoMusical extends Evento implements Comparable<EventoMusical>, CSVSerializable {
    private String artista;
    private GeneroMusical genero;

    public EventoMusical(int id, String nombre, LocalDate fecha, String artista, GeneroMusical genero) {
        super(id, nombre, fecha);
        this.artista = artista;
        this.genero = genero;
    }

    public String getArtista() {
        return artista;
    }

    public GeneroMusical getGenero() {
        return genero;
    }

    @Override
    public int compareTo(EventoMusical o) {
        return this.fecha.compareTo(o.getFecha());
    }
    
    @Override
    public String toCSV() {
        return id + "," + nombre + "," + fecha + "," + artista + "," + genero;
    }

    public static String toHeaderCSV() {
        return "ID,Nombre,Fecha,Artista,Género";
    }
    

    public static EventoMusical fromCSV(String archivoCSV) {
        String[] linea = archivoCSV.split(",");
        
        if (linea.length != 5) {
            throw new IllegalArgumentException("Error en el archivo.");
        }
        
        int id = Integer.parseInt(linea[0]);
        String nombre = linea[1];
        LocalDate fecha = LocalDate.parse(linea[2]);
        String artista = linea[3];
        GeneroMusical generoMusical = GeneroMusical.valueOf(linea[4].toUpperCase());
        return new EventoMusical(id, nombre, fecha, artista, generoMusical);
    }
 

    @Override
    public String toString() {
        return super.toString() + ", artista='" + artista + '\'' + ", genero=" + genero;
    }
}
