package service;

import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;

public interface Gestionable<T> {
    void agregar(T item);
    void eliminar(int id);
    List<T> filtrar(Predicate<T> criterio);
    void ordenar(Comparator<T> comparator);
    void mostrarTodos();
} 