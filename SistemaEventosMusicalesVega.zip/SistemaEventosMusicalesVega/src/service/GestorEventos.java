
package service;

import model.EventoMusical;
import java.io.*;
import java.util.*;
import java.util.function.Function;
import java.util.function.Predicate;

public class GestorEventos<T extends EventoMusical> implements Gestionable<T>, Serializable {
    private List<T> eventos = new ArrayList<>();

    @Override
    public void agregar(T evento) {
        eventos.add(evento);
    }

    @Override
    public void eliminar(int id) {
        eventos.removeIf(e -> e.getId() == id);
    }

    @Override
    public List<T> filtrar(Predicate<T> criterio) {
        return eventos.stream().filter(criterio).toList();
    }

    @Override
    public void ordenar(Comparator<T> comparator) {
        eventos.sort(comparator);
    }

    @Override
    public void mostrarTodos() {
        eventos.forEach(System.out::println);
    }

    public void guardarCSV(String ruta) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(ruta))) {
            writer.write(EventoMusical.toHeaderCSV());
            writer.newLine();
            for (T evento : eventos) {
                writer.write(evento.toCSV());
                writer.newLine();
            }
        }
    }

    public void cargarCSV(String ruta, Function<String, T> fromCSV) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(ruta))) {
            reader.readLine(); // Saltar el encabezado
            String linea;
        while ((linea = reader.readLine()) != null) {
            eventos.add(fromCSV.apply(linea)); // Usa la función pasada como argumento para convertir la línea
        }
    }
}

    public void guardarEnBinario(String ruta) throws IOException {
    try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ruta))) {
        oos.writeObject(eventos); // Serializa la lista completa de eventos
    }
    }
    public void cargarDesdeBinario(String ruta) throws IOException, ClassNotFoundException {
    try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ruta))) {
        eventos = (List<T>) ois.readObject(); // Deserializa la lista de eventos
    }
    }
}

